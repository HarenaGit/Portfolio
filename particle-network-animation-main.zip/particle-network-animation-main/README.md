# particle-network-animation

This project is a animation experiment with randomly generated particles and connectors. The project is wittern in HTML, CSS and JavaScript.

# Website

https://abjt14.github.io/particle-network-animation

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License
[MIT](https://choosealicense.com/licenses/mit/)
